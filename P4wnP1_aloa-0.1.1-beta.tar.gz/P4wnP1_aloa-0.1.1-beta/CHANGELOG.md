# changelog

## v0.1.1-beta

- fix #81: 100 percent CPU load in WiFI STA mode
- fix: Italian layout `it`
- fix: UK layout `gb`
- fix: French layout `fr`
- fix #38: file permission
- added Finnish `fi` and Swedish `sv` layout (same)
- added German(Switzerland) layout `ch`
- added French(Belgian) layout `be`
