DISCLAIMER
==========

**P4wnP1 A.L.O.A.** is dedicated to penetration testers, redteamers and InfoSec personal.
It should be used for authorized testing and/or educational purposes only. 
The only exception is using it against devices or a network, owned by yourself.

I take no responsibility for the abuse of P4wnP1 A.L.O.A. or any information given in the 
related documents. 

**I DO NOT GRANT PERMISSIONS TO USE P4wnP1 A.L.O.A. TO BREAK THE LAW.**

As P4wnP1 A.L.O.A. is in alpha stage, it is likely that bugs occur.
I disclaim any warranty for P4wnP1 A.L.O.A., it is provided "as is".
