package cli_client

import "time"

const (
	TIMEOUT_SHORT = time.Second * 5
	TIMEOUT_MEDIUM = time.Second * 10
	TIMEOUT_LONG = time.Second * 30
)
