package main

import (
	"github.com/mame82/P4wnP1_aloa/cli_client"
)

func main() {
	cli_client.Execute()
}
