package common_web

const (
	MAJOR = 0
	MINOR = 1
	PATCH = 1
	SUFFIX = "-beta"
	VERSION = "v0.1.1"+SUFFIX
)
