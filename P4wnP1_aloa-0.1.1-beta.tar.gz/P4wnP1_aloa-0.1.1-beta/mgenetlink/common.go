package mgenetlink

import "github.com/mame82/P4wnP1_aloa/mnetlink"

var hbo = mnetlink.Hbo()
