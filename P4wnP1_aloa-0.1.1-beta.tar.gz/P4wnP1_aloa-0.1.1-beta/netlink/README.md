This folder contains an extended version of 

github.com/docker/libcontainer

The changes to the original (which only consists of additions) could be seen in `docker.diff`.

The LICENSE of the unmodified library applies (Apache-2.0).

Please see the LICENSE and NOTICE file for details.

It is planned to migrate the needed functionality of this library, which is needed to work for P4wnP1 A.L.O.A. to the 
`mnetlink` library of this project, as soon as there is the time to do so.  