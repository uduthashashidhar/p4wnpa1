#!/bin/bash

# dependencies for the web app
gopherjs build -o ../www/webapp.js #main.go
