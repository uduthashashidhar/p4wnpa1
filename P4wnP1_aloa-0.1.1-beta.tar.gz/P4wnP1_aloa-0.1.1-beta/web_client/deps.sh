#!/bin/bash

# dependencies for the web app
go get -u honnef.co/go/js/dom
